﻿IBM-Project-14720-1659589096

SmartFarmer - IoT Enabled Smart Farming Application

Team leader : Nishanth G

Team Members : Kesavamoorthi J, Mayavan A, Saravana perumal V
